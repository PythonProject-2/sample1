For documentation

http://createwebsite.net/freebies/shopme/documentation.html



V1.0.0(22/9/2016)
Initial Version Release.

